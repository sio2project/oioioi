#include <iostream>

void test_case() {
    long long n;
    std::cin >> n;
    std::cout << n * n << std::endl;
}

int main() {
    int test_cases;
    std::cin >> test_cases;
    while (test_cases--) {
        test_case();
    }
    return 0;
}
