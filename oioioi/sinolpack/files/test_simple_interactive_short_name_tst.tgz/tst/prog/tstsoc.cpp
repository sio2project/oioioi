#include <bits/stdc++.h>
#include <assert.h>

using namespace std;

void _result(bool correct, int points, string comment) {
    cout << (correct ? "OK" : "WRONG") << endl << flush << flush;
    cout << comment << endl << flush;
    cout << points << endl << flush;
    exit(0);
}

void fail(string comment = "", int points = 0) {
    _result(false, points, comment);
}

void success(string comment = "", int points = 100) {
    _result(true, points, comment);
}

int main(int argc, char *argv[]) {
    int num_processes = stoi(argv[1]);
    if (num_processes != 1) {
        fail("Wrong number of processes");
    }
    if (argc != 2 + 2 * num_processes) {
        fail("Wrong number of arguments");
    }
    FILE *in = fdopen(atoi(argv[2]), "r");
    FILE *out = fdopen(atoi(argv[3]), "w");
    assert(in != NULL);
    assert(out != NULL);

    int test_cases;
    cin >> test_cases;

    fprintf(out, "%d\n", test_cases);
    fflush(out);

    for (int i = 0; i < test_cases; ++i) {
        fprintf(out, "%d\n", i);
        fflush(out);
        long long user;
        fscanf(in, "%lld", &user);
        if (feof(in) || ferror(in)) {
            // Exit with sigpipe. Interactor could also exit with WA and a proper comment.
            return 128 + 13;
        }
        if (user != (long long)i * i) {
            fail("Wrong number, user: " + to_string(user) + " i: " + to_string(i));
        }
    }
    success();
    return 0;
}
