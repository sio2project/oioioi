#include <iostream>

void test_case() {
    long long n;
    std::cin >> n;
    std::cout << n * n << std::endl;
}

int main() {
    int test_cases;
    std::cin >> test_cases;
    while (test_cases--) {
        test_case();
    }
    
    int non_existing;
    std::cin >> non_existing;
    return 0;
}
