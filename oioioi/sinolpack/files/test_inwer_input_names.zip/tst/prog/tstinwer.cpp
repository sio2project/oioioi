#include <cstdio>
#include <cstring>

using namespace std;

int main(int argc, char const *argv[]) {
    if (argc != 2) {
        printf("WRONG\nWrong number of arguments");
        return 1;
    }
    int a, b;
    scanf("%d %d", &a, &b);
    const char* correct_test_names[4] = {"tst0.in", "tst1a.in", "tst2a.in", "tst2b.in"};
    if (strcmp(argv[1], correct_test_names[a + b]) == 0) {
        printf("OK\n");
    } else {
        printf("WRONG\n");
        return 1;
    }
    return 0;
}
