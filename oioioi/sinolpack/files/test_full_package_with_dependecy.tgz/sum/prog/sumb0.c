#include <stdio.h>

int main(int argc, char** argv) {
    printf("3\n");
    return 0;
}
