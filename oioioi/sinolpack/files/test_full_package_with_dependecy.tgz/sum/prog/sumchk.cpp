#include "oi.h"

#include <cstdio>
#include <cstdlib>
#include <string.h>
using namespace std;

void wrong_answer(const char *msg, int line=0, int position=0){
	printf("WRONG\n%s\n",msg);
    exit(0);
}

int main(int argc, char **argv) {
    int n, m;
    char ret_buffer[100];
    assert(argc==4);

    freopen(argv[1], "r", stdin);
    scanf("%d%d", &n, &m);

    freopen(argv[2], "r", stdin);
    oi::Scanner input(stdin, wrong_answer, oi::EN);
    int s = input.readInt(-1, 100000);
    int sum = n + m;
    if (s < sum - 1 || s > sum + 1) {
        sprintf(ret_buffer, "expected %d +/- 1, got %d", sum, s);
        wrong_answer(ret_buffer);
    }
    input.skipWhitespaces();
    input.readEof();
    puts("OK");
    return 0;
}
