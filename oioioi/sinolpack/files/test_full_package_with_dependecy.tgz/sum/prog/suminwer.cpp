#include "oi.h"

using namespace std;

const int MAXAB = 10000;

int a, b;

int main(){
  oi::Scanner input(stdin, oi::EN);;
  a = input.readInt(0, MAXAB);
  input.readSpace();
  b = input.readInt(0, MAXAB);
  input.readEoln();
  input.readEof();
  return 0;
};
