#include <stdio.h>
#include "makra.h"

#ifndef ELOZIOM
#error ELOZIOM not defined, but mandated in config.yml
#endif

int main(int argc, char** argv) {
    INT(a); INT(b);
    printf("%d\n", a+b);
    return 0;
}
