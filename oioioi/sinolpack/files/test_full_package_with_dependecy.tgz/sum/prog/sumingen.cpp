/*
   Generator testow do zadania DIS
   Autor - Adam Karczmarz
*/
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include "oi.h"
#include <set>

#define REP(AA,BB) for(int AA=0; AA<(BB); ++AA)
#define FOR(AA,BB,CC) for(int AA=(BB); AA<(CC); ++AA)
#define FC(AA,BB) for(__typeof((AA).begin()) BB=(AA).begin(); BB!=(AA).end(); ++BB)
#define SZ(AA) ((int)((AA).size()))
#define ALL(AA) (AA).begin(), (AA).end()
#define PB push_back
#define MP make_pair

using namespace std;

oi::Random RG;

void zapisz(const char *name) {
	FILE* f=fopen(name, "w");
	fprintf(f, "%d %d\n", int(name[3] - '0'), RG.rand() % 10001);
	fclose(f);
}

int main(void) {
    zapisz("sum2.in");
    zapisz("sum3.in");
    zapisz("sum1ocen.in");
	return 0;
}
