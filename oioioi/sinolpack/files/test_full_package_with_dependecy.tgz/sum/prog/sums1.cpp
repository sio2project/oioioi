#include <iostream>

using namespace std;

int main() {
    int a, b;
    long long s = 0;
    cin >> a >> b;
    while (a) {
        for (int i = 0; i < 10000; i++) {
            s++;
        }
        a--;
    }
    while (b) {
        for (int i = 0; i < 10000; i++) {
            s++;
        }
        b--;
    }
    cout << s / 10000 << endl;
    return 0;
}
