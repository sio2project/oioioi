#include<cstdio>

int main() {
    printf("ZLE\n");
    return 1;
}
