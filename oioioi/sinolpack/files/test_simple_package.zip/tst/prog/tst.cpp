#include <iostream>
#include <queue>
#include <utility>
#include <vector>

using namespace std;

typedef pair<int, long long> pil;

const int N = 5009;
const long long INF = 1e9;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(NULL);

    int n;
    long long prices[N];

    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> prices[i];
    }

    int m, a, b;
    long long c;
    vector<pil> graph[N], graph_rev[N];
    
    cin >> m;
    for(int i = 1; i <= m; i++) {
        cin >> a >> b >> c;

        graph[a].push_back({b, c});
        graph_rev[b].push_back({a, c});
    }

    vector<long long> dist(N, INF);
    vector<int> vis(N, 0);
    priority_queue<pil, vector<pil>, greater<pil>> Q;

    // Calculate distances 1 -> i
    Q.push({0, 1});
    dist[1] = 0;
    while(!Q.empty()) {
        int v = Q.top().second;
        Q.pop();

        if(vis[v] == 1) {
            continue;
        }

        for(int i = 0; i < (int) graph[v].size(); i++) {
            int w = graph[v][i].first;
            long long cost = graph[v][i].second;

            if(dist[v] + cost < dist[w]) {
                dist[w] = dist[v] + cost;
                Q.push({dist[w], w});
            }
        }

        vis[v] = 1;
    }

    // Calculate distances i -> 1
    for(int i = 1; i <= n; i++) {
        vis[i] = 0;
    }
    vector<long long> dist_rev(N, INF);

    Q.push({0, 1});
    dist_rev[1] = 0;
    while(!Q.empty()) {
        int v = Q.top().second;
        Q.pop();

        if(vis[v] == 1) {
            continue;
        }

        for(int i = 0; i < (int) graph_rev[v].size(); i++) {
            int w = graph_rev[v][i].first;
            long long cost = graph_rev[v][i].second;

            if(dist_rev[v] + cost < dist_rev[w]) {
                dist_rev[w] = dist_rev[v] + cost;
                Q.push({dist_rev[w], w});
            }
        }

        vis[v] = 1;
    }

    long long ans = prices[1] / 2;
    for(int i = 2; i <= n; i++) {
        if(dist[i] == INF || dist_rev[i] == INF) {
            continue;
        }

        long long new_ans = prices[i] / 2 + dist[i] + dist_rev[i];
        ans = min(ans, new_ans);
    }

    cout << ans << "\n";
}