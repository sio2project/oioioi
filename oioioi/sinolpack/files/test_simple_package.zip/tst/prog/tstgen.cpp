#include <algorithm>
#include <fstream>
#include <random>
#include <tuple>
#include <vector>

const int MAX_N = 5000;
const int MAX_M = 100000;
const int MAX_PRICE = 10000;

using namespace std;

typedef tuple<int, int, int> transform_t;

std::mt19937 gen(1234);
auto rng = [](int n) {
    return std::uniform_int_distribution<int>(0, n-1)(gen);
};

void cycle(ofstream& of) {
    int n = 2000;

    of << n << "\n";

    int cost;
    for(int i = 1; i <= n; i++) {
        if(i == 1) {
            cost = 2 * n;
        } else if(i == n / 2) {
            cost = n - 1;
        } else {
            cost = n;
        }

        of << 2 * cost << "\n";
    }
    of << "\n";

    vector<transform_t> transforms;
    for(int i = 1; i <= n; i++) {
        transforms.push_back({i, (i % n) + 1, 1});
    }

    random_shuffle(transforms.begin(), transforms.end(), rng);

    for(auto e : transforms) {
        of << get<0>(e) << " " << get<1>(e) << " " << get<2>(e) << "\n";
    }
}

void double_cycle(ofstream &of) {
    int n = 1000;

    of << n << "\n";

    int cost = 190 * 50; // 0 * 49 + (1 + 2 + ... + 19) * 50

    for(int i = 1; i <= n - 2; i++) {
        of << 4 * cost + 80 << "\n";
        cost -= i / 50;
    }
    of << 76 << "\n";
    of << 0  << "\n";

    vector<transform_t> transforms(2 * n);
    for(int i = 1; i <= n - 1; i++) {
        transforms[i - 1] = {i, i + 1, (i + 1) / 50};
        transforms[i + n - 1] = {i + 1, i, (i + 1) / 50};
    }

    transforms[n - 1] = {n, 1, 10000};
    transforms[2 * n - 1] = {1, n, 10000};

    random_shuffle(transforms.begin(), transforms.end(), rng);

    for(auto e : transforms) {
        of << get<0>(e) << " " << get<1>(e) << " " << get<2>(e) << "\n";
    } 
}

void clique(ofstream &of, int limit) {
    int n = 100;

    of << n << "\n";

    for(int i = 1; i <= n; i++) {
        of << 2 * rng(limit) << "\n";
    }

    vector<transform_t> transforms;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            if(i != j) {
                transforms.push_back({i, j, rng(MAX_PRICE + 1)});
            }
        }
    }
    
    random_shuffle(transforms.begin(), transforms.end(), rng);

    for(auto e : transforms) {
        of << get<0>(e) << " " << get<1>(e) << " " << get<2>(e) << "\n";
    } 
}

int main() {
    for(int i = 5; i <= 10; i++) {
        ofstream test("../in/tst" + std::to_string(i) + ".in");

        switch(i) {
            case 5:
                cycle(test);
                break;
            case 6:
                double_cycle(test);
                break;
            case 7:
                clique(test, 314159);
                break;
            case 8:
                cycle(test);
                break;
            case 9:
                double_cycle(test);
                break;
            case 10:
                clique(test, 271828);
                break;
        }

        test.close();
    }
}