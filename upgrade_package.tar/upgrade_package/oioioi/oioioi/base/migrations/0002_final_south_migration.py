# -*- coding: utf-8 -*-
from south.v2 import SchemaMigration

class Migration(SchemaMigration):

    depends_on = (
            ("zeus", "0005_auto__del_field_zeusasyncjob_kind__add_field_zeusasyncjob_resumed.py"),
            ("testspackages", "0001_initial.py"),
            ("testrun", "0001_initial.py"),
            ("teams", "0002_auto__add_field_teamsconfig_teams_list_visible.py"),
            ("teachers", "0007_separate_key_for_joining_teachers_part_3.py"),
            ("suspendjudge", "0001_initial.py"),
            ("submitsqueue", "0002_auto__add_field_queuedsubmit_id__chg_field_queuedsubmit_submission__de.py"),
            ("submitservice", "0001_initial.py"),
            ("statistics", "0001_initial.py"),
            ("sinolpack", "0004_auto__del_field_originalpackage_package_file.py"),
            ("sharingcli", "0001_initial.py"),
            ("scoresreveal", "0001_initial.py"),
            ("questions", "0008_auto__add_field_replytemplate_usage_count.py"),
            ("publicsolutions", "0001_initial.py"),
            ("programs", "0014_auto__add_useroutgenstatus__add_reportactionsconfig__add_field_testrep.py"),
            ("problems", "0005_move_package_files_from_sinolpack_origpack_to_problempackage.py"),
            ("prizes", "0001_initial.py"),
            ("participants", "0003_auto__add_field_participant_anonymous.py"),
            ("pa", "0005_auto__add_paprobleminstancedata.py"),
            ("oisubmit", "0003_suspected_kind.py"),
            ("oi", "0006_auto__chg_field_oiregistration_school.py"),
            ("notifications", "0001_initial.py"),
            ("ipdnsauth", "0001_initial.py"),
            ("forum", "0004_link_last_post.py"),
            ("dashboard", "0001_initial.py"),
            ("contests", "0021_auto__add_field_contest_contact_email.py"),
            ("contestlogo", "0005_auto__add_field_contestlogo_link.py"),
            ("contestexcl", "0001_initial.py"),
            ("complaints", "0001_initial.py"),
            ("balloons", "0003_auto__add_balloondelivery__add_balloonsdeliveryaccessdata.py"),
            ("acm", "0002_auto__del_roundrankingfreeze__del_contestdefaultrankingfreeze.py"),
    )

    def forwards(self, orm):
        pass
    def backwards(self, orm):
        pass
