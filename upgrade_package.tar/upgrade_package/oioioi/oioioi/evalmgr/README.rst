Evaluation Manager is a module taking a recipe along with parameters
in 'env' variable (large dictionary) and processing it
according to a recipe. This process is used to compile, execute and
grade submissions in a programming contest.
