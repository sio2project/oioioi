#!/bin/bash
. ../venv/bin/activate
for pip_package in 'django>=1.6,<1.7' 'south' 'filetracker' 'psycopg2' 'celery'
do
	pip install $pip_package
done
./manage.py syncdb --noinput
./manage.py migrate
