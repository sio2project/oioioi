/* Rozwiazanie bledne zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Opis: zlicza populacj� miast parzystych oraz nieparzystych i wybiera max
 * Zlozonosc czasowa: O(n)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    int n;
    int a;
    long long res[2]={};
    
    scanf("%d", &n);
    
    for (int i=0; i<n; ++i)
    {
        scanf("%d", &a);
        res[i&1]+=a;
    }
    
    printf("%lld\n", max(res[0], res[1]) );
    
    return 0;
}