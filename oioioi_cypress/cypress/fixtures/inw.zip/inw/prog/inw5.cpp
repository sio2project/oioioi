/* Potyczki Algorytmiczne 2012
 * Zadanie: INW/tidz029/Inwazja kosmitow
 * Rozwiazanie wzorcowe (alternatywne)
 * Autor: Karol Pokorski
 */

#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 1000001;

int n, t[MAXN];
long long int dp[MAXN];

int main() {
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &t[i]);

	dp[0] = t[0];
	for (int i = 1; i < n; i++)
		dp[i] = max(dp[i-1], dp[i-2]+t[i]);
	
	printf("%lld\n", max(dp[n-1], dp[n-2]));
		
	return 0;
}
