/* Rozwiazanie wolne zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Opis: dynamik kwadratowy
 * Zlozonosc czasowa: O(n^2)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

const int MAX_N = 1000*1000+10;

int a[MAX_N]={};
long long res[MAX_N]={};


int main()
{
    int n;
    long long int finalRes=0;
    
    scanf("%d", &n);
    
    for (int i=1; i<=n; ++i)
        scanf("%d", &a[i]);
    
    for (int i=1; i<=n; ++i)
    {
        for (int j=1; j<=i-2; ++j)
            res[i] = max(res[i], res[j]);
        
        res[i] += a[i];
    }
    
    for (int i=0; i<=n; ++i)
        finalRes = max(finalRes, res[i]);
    
    printf("%lld\n", finalRes);
    
    return 0;
}