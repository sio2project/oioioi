/* Rozwiazanie wzorcowe zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Zlozonosc czasowa: O(n)
 * Zlozonosc pamieciowa: O(1)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    int n;
    int a;
    long long wyn[2]={};
    
    scanf("%d", &n);
    
    for (int i=0; i<n; ++i)
    {
        scanf("%d", &a);
        wyn[(i&1)] = max(wyn[((i+1)&1)], wyn[(i&1)] + a);
    }
    
    printf("%lld\n", max(wyn[0], wyn[1]) );
    
    return 0;
}