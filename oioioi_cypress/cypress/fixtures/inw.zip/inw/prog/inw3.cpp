/* Rozwiazanie wzorcowe zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Opis: dynamik rekurencyjny
 * Zlozonosc czasowa: O(n)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

const int MAX_N = 1000*1000+10;

int a[MAX_N]={};
long long res[MAX_N]={};

long long askForRes(int pos)
{
    if (pos <= 0)
        return 0;
    
    if (res[pos] != -1)
        return res[pos];
    
    res[pos] = max(askForRes(pos-1), askForRes(pos-2) + a[pos]);
    
    return res[pos];
}


int main()
{
    int n;
    
    scanf("%d", &n);
    
    for (int i=1; i<=n; ++i)
    {
        res[i] = -1;
        scanf("%d", &a[i]);
    }
    
    printf("%lld\n", askForRes(n));
    
    return 0;
}