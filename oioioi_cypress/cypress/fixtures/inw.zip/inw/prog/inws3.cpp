/* Potyczki Algorytmiczne 2012
 * Zadanie: INW/tidz029/Inwazja kosmitow
 * Rozwiazanie naiwne - rekurencja ze spamiętywaniem, za wolne
 * Autor: Karol Pokorski
 */

#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 2001;

typedef long long int LL;

int n, t[MAXN];
LL dp[MAXN][MAXN];

LL Go(int a, int b) {
	if (dp[a][b] != -1)
		return dp[a][b];
	if (a > b)
		return 0;
	if (a == b)
		return t[a];
	
	return max(max(Go(a+2, b)+t[a], Go(a, b-2)+t[b]), max(Go(a+1, b), Go(a, b-1)));
}

int main() {
	scanf("%d", &n);

	if (n >= MAXN)
		for (;;);

	for (int i = 0; i < n; i++)
		fill(dp[i], dp[i]+n, -1);

	for (int i = 0; i < n; i++)
		scanf("%d", &t[i]);

	printf("%lld\n", Go(0, n-1));
		
	return 0;
}
