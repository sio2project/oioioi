/* Generator testow do zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 */

#include "oi.h"
#include <cstdio>
#include <vector>
#include <utility>
#include <map>
#include <set>
#include <string>

using namespace std;
using namespace oi;


const int MAX_N = 1000*1000;
const int MAX_A = 1000*1000*1000;

vector<int> input;


void saveToFile(const string& filename)
{
		printf("%s...", filename.c_str());

    FILE * pFile;
    pFile = fopen (filename.c_str(), "w");
    
    if (pFile==NULL)
    {
        fprintf(stderr, "ERROR while writing to file %s\n", filename.c_str());
        return;
    }
    
    
    fprintf(pFile, "%d\n", (int)input.size());
    
    for (vector<int>::iterator vit = input.begin(); vit!=input.end(); )
    {
        fprintf(pFile, "%d", *vit);
        ++vit;
        
        if (vit!=input.end())
            fprintf(pFile, " ");
    }
    
    fprintf(pFile, "\n");
    
    if (fclose (pFile) == EOF)
    {
        fprintf(stderr, "ERROR while closing file %s\n", filename.c_str());
        return;
    }
    
		printf("OK\n");
}


void seq(unsigned from, unsigned to)
{
    for (unsigned i=from; i<=to; ++i)
        input.push_back(i);
}

void copy(unsigned n, unsigned elem)
{
    for (unsigned i=1; i<=n; ++i)
        input.push_back(elem);
}

void flipflop(unsigned n, unsigned elem1, unsigned elem2)
{
    for (unsigned i=1; i<=n; ++i)
        input.push_back( (i&1) ? elem1 : elem2 );
}

void random(unsigned seed, unsigned n, unsigned minimal, unsigned maximal)
{
    Random R(seed);
    
    for (unsigned i=1; i<=n; ++i)
        input.push_back( (R.randUInt()%(maximal-minimal+1))+minimal );
} 

void randomization(unsigned seed, unsigned swaps) {
	Random R(seed);

	for (unsigned i=0; i<swaps; i++)
		swap(input[R.rand()%input.size()], input[R.rand()%input.size()]);
}

int main()
{
    //Test 1:
    seq(1, 10);
    saveToFile("inw1a.in");
    input.clear();
    
    //Test 2 (obala inwb2.cpp):
    flipflop(3, 5, 7);
    saveToFile("inw1b.in");
    input.clear();
    
    //Test 3:
    copy(100, 0);
    saveToFile("inw2a.in");
    input.clear();
    
    //Test 4:
    flipflop(100000, 9, 17);
    saveToFile("inw3a.in");
    input.clear();
    
    //Test 5 (max test - obala inwb1.cpp):
    copy(MAX_N, MAX_A);
    saveToFile("inw3b.in");
    input.clear();
    
    //Test 6:
    random(1253, MAX_N, 0, 1);
    saveToFile("inw3c.in");
    input.clear();
    
    //Test 7:
    random(7433, MAX_N, 0, MAX_A);
    saveToFile("inw3d.in");
    input.clear();
    
    //Test 8:
    random(4223, MAX_N, 0, MAX_A);
    saveToFile("inw3e.in");
    input.clear();
    
    //Test 9:
    random(743233, MAX_N, 0, MAX_A);
    saveToFile("inw3f.in");
    input.clear();
    
    //Test 10:
    random(53227, MAX_N, 0, MAX_A);
    saveToFile("inw3g.in");
    input.clear();
    
    //Test 11:
    copy(MAX_N-3, MAX_A-52);
    saveToFile("inw3h.in");
    input.clear();
    
    //Test 12:
    random(43, MAX_N, MAX_A/2, MAX_A);
    saveToFile("inw3i.in");
    input.clear();

		//Test 13:
		random(123, 10000, MAX_A/3, MAX_A);
		copy(10000, MAX_A/2);
		flipflop(10000, MAX_A/4, MAX_A);
		randomization(1347861, 70);
		saveToFile("inw2b.in");
		input.clear();

		//Test 14:
		copy(10000, 52);
		flipflop(10000, 50, 51);
		copy(10000, 52);
		randomization(1123412, 70);
		saveToFile("inw2c.in");
		input.clear();

		//Test 15:
		copy(10000, 0);
		flipflop(10000, 1, 0);
		copy(10000, 0);
		randomization(123764, 1000);
		saveToFile("inw2d.in");
		input.clear();

		//Test 16:
		flipflop(30001, 999999, 1000000);
		saveToFile("inw2e.in");
		input.clear();

		//Test 17:
		flipflop(30001, 999999, 1000000);
		flipflop(25000, 999999, 1000000);
		saveToFile("inw4a.in");
		input.clear();

		//Test 18:
		flipflop(30000, 1000000, 999999);
		flipflop(25001, 1000000, 999999);
		saveToFile("inw4b.in");
		input.clear();

		//Test 19:
		flipflop(70001, 999999, 1000000);
		randomization(1782417, 40);
		saveToFile("inw4c.in");
		input.clear();

		//Test 20:
		copy(MAX_N, 0);
		saveToFile("inw4d.in");
		input.clear();
		
		//Test 21:
		seq(1, 100000);
		randomization(178246, 1000);
		saveToFile("inw4e.in");
		input.clear();

		//Test 22:
		flipflop(100000, 30, 0);
		seq(1, 1000);
		randomization(78461, 140);
		saveToFile("inw4f.in");
		input.clear();
    
    return 0;
}
