/* Rozwiazanie wzorcowe zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Zlozonosc czasowa: O(n)
 * Zlozonosc pamieciowa: O(1)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    int n;
    int a;
    long long wyn[2][2]={};		//wynik jesli i-te miasto nalezy do P i jesli nie nalezy
    
    scanf("%d", &n);
    
    for (int i=0; i<n; ++i)
    {
        scanf("%d", &a);
        wyn[(i&1)][0] = max(wyn[((i+1)&1)][0], wyn[((i+1)&1)][1]);
        wyn[(i&1)][1] = wyn[((i+1)&1)][0] + a;
    }
    
    printf("%lld\n", max(wyn[((n+1)&1)][0], wyn[((n+1)&1)][1]) );
    
    return 0;
}