/* Rozwiazanie bledne zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Opis: Zachlanne wybieranie najbardziej zaludnionego miasta nie sasiadujacego z juz zaatakowanym
 * Zlozonosc czasowa: O(n log n)
 */

#include <cstdio>
#include <algorithm>
#include <utility>

using namespace std;

const int MAX_N = 1000*1000+10;

pair<int, int> order[MAX_N];		//value, position
int a[MAX_N]={};
bool alerted[MAX_N]={};

int main()
{
    int n;
    long long res = 0;
    
    scanf("%d", &n);
    
    for (int i=1; i<=n; ++i)
    {
        scanf("%d", &a[i]);
        order[i] = make_pair(a[i], i);
    }
    
    sort(&order[1], &order[n+1]);
    
    for (int i=n; i>0; --i)
    {
        if (alerted[order[i].second])
            continue;
        
        res += order[i].first;
        
        alerted[order[i].second-1] = true;
        alerted[order[i].second] = true;
        alerted[order[i].second+1] = true;
    }
    
    printf("%lld\n", res);
    
    return 0;
}