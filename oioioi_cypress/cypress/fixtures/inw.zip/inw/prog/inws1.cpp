/* Rozwiazanie wolne zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Opis: dynamik bez spami�tywania
 * Zlozonosc czasowa: O(2^n)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

const int MAX_N = 1000*1000+10;

int a[MAX_N]={};


long long askForRes(int pos)
{
    if (pos <= 0)
        return 0;
    
    return max(askForRes(pos-1), askForRes(pos-2) + a[pos]);
}


int main()
{
    int n;
    
    scanf("%d", &n);
    
    for (int i=1; i<=n; ++i)
        scanf("%d", &a[i]);
    
    printf("%lld\n", askForRes(n));
    
    return 0;
}