/* Rozwiazanie wzorcowe zadania "Inwazja kosmitow"
 * Autor: Bartlomiej Gajewski
 * Opis: ulepszony inws2.cpp
 * Zlozonosc czasowa: O(n)
 */

#include <cstdio>
#include <algorithm>

using namespace std;

const int MAX_N = 1000*1000+10;

int a[MAX_N]={};
long long res[MAX_N]={};


int main()
{
    int n;
    long long int finalRes=0;
    long long int sofarMax=0;
    
    scanf("%d", &n);
    
    for (int i=1; i<=n; ++i)
        scanf("%d", &a[i]);
    
    for (int i=1; i<=n; ++i)
    {
        if (i-2 >= 1)
            sofarMax = max(sofarMax, res[i-2]);
        
        res[i] = sofarMax + a[i];
    }
    
    for (int i=0; i<=n; ++i)
        finalRes = max(finalRes, res[i]);
    
    printf("%lld\n", finalRes);
    
    return 0;
}