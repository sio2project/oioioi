/*
 * Zadanie: INW
 * Autor: Tomasz Idziaszek
 * Data: 15.09.2012
 * Typ: Weryfikator testów
 */
#include "oi.h"
using namespace std;

const int MAXN = 1000*1000;
const int MAXL = 1000*1000*1000;

using namespace std;

int main() {
   oi::Scanner test(stdin);
   int n = test.readInt(1, MAXN);
   test.readEoln();
   for(int i = 0; i < n; ++i) {
      if (i) test.readSpace();
      test.readInt(0, MAXL);
   }
   test.readEoln();
   test.readEof();
   printf("OK  n = %6d\n", n);
   return 0;
}

